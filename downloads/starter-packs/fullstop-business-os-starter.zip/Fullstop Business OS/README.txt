Import this template into Notion (Import -> Markdown) or Obsidian.
Visit https://www.fullstopsolution.in for daily tools.
