# Independent Contractor Agreement

Standard 2026 contractor agreement with intellectual property assignment and confidentiality clauses.
