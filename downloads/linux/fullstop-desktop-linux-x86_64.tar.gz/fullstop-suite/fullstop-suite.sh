#!/bin/sh
DIR="$( cd "$( dirname "$0" )" >/dev/null 2>&1 && pwd )"
if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$DIR/app/index.html"
elif command -v sensible-browser >/dev/null 2>&1; then
    sensible-browser "$DIR/app/index.html"
else
    echo "Please open $DIR/app/index.html in your browser."
fi
