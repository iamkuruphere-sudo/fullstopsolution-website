#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
TARGET="file://$DIR/app/index.html"

for BROWSER in google-chrome google-chrome-stable chromium-browser chromium brave-browser microsoft-edge; do
  if command -v "$BROWSER" >/dev/null 2>&1; then
    "$BROWSER" --app="$TARGET" >/dev/null 2>&1 &
    exit 0
  fi
done

if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$TARGET" >/dev/null 2>&1 &
elif command -v sensible-browser >/dev/null 2>&1; then
    sensible-browser "$TARGET" >/dev/null 2>&1 &
elif command -v firefox >/dev/null 2>&1; then
    firefox "$TARGET" >/dev/null 2>&1 &
else
    echo "Fullstop Suite: Please open $TARGET in your browser."
fi
