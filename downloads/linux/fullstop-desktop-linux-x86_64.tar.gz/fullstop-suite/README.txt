======================================================================
FULLSTOP SUITE — LINUX (x86_64)
Official Website: https://www.fullstopsolution.in
Security Architecture: 100% Client-Side Memory, Zero Telemetry
======================================================================

QUICK START:
Option 1 (Automated Desktop Integration):
  chmod +x install-linux.sh
  ./install-linux.sh

Option 2 (Standalone Portable):
  chmod +x fullstop-suite.sh
  ./fullstop-suite.sh

HOW TO VERIFY SIGNATURE INTEGRITY:
Run in terminal:
  sha256sum fullstop-desktop-linux-x86_64.tar.gz
