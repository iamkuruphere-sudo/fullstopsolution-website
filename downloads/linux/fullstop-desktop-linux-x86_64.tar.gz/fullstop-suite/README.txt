======================================================================
FULLSTOP SOLUTION DESKTOP SUITE - LINUX (x86_64 / Universal)
Official Website: https://www.fullstopsolution.in
Security Architecture: 100% Client-Side Memory, Zero Telemetry
======================================================================

QUICK START:
1. Make launcher executable: chmod +x fullstop-suite.sh
2. Run ./fullstop-suite.sh or open app/index.html in Firefox / Chromium.

HOW TO VERIFY SIGNATURE INTEGRITY:
Run in terminal:
  sha256sum fullstop-desktop-linux-x86_64.tar.gz
