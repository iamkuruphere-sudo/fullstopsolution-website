#!/usr/bin/env bash
# Fullstop Suite — Automated Linux Desktop Integration Script
set -euo pipefail
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

echo "================================================================="
echo " Installing Fullstop Suite to ~/.local/share/applications"
echo "================================================================="

APP_DIR="$HOME/.local/share/fullstop-suite"
ICON_DIR="$HOME/.local/share/icons/hicolor/256x256/apps"
DESKTOP_DIR="$HOME/.local/share/applications"

mkdir -p "$APP_DIR" "$ICON_DIR" "$DESKTOP_DIR"

# Copy workstation assets
cp -R "$DIR/app" "$APP_DIR/"
cp "$DIR/fullstop-suite.sh" "$APP_DIR/"
chmod +x "$APP_DIR/fullstop-suite.sh"

# Install icon
if [ -f "$DIR/app/assets/images/logo.png" ]; then
    cp "$DIR/app/assets/images/logo.png" "$ICON_DIR/fullstop-suite.png"
fi

# Write desktop entry with absolute paths
cat << EOF > "$DESKTOP_DIR/fullstop-suite.desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=Fullstop Suite
GenericName=Offline Toolkit
Comment=Zero-Knowledge Offline Desktop Workstation
Exec=$APP_DIR/fullstop-suite.sh
Icon=fullstop-suite
Terminal=false
Categories=Utility;Development;Security;
StartupNotify=true
EOF

chmod +x "$DESKTOP_DIR/fullstop-suite.desktop"

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
fi

echo "✓ Fullstop Suite successfully integrated into your application launcher!"
echo "Launching Fullstop Suite..."
"$APP_DIR/fullstop-suite.sh"
