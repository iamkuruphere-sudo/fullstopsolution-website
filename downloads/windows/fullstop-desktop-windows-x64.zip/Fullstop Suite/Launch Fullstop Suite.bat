@echo off
title Fullstop Solution Desktop Suite (Offline & Private)
echo Starting Fullstop Solution Desktop Suite...
start "" "%~dp0app\index.html"
exit
