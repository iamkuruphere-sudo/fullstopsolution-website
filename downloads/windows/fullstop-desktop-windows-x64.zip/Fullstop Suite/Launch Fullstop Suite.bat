@echo off
setlocal enabledelayedexpansion
title Fullstop Suite Desktop Workstation
set "DIR=%~dp0"
set "TARGET=file:///%DIR%app/index.html"

echo Starting Fullstop Suite Desktop Workstation...

where msedge >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" msedge --app="%TARGET%"
    exit /b 0
)

where chrome >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" chrome --app="%TARGET%"
    exit /b 0
)

start "" "%DIR%app\index.html"
exit /b 0
