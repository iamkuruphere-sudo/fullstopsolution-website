@echo off
setlocal enabledelayedexpansion
title Fullstop Suite Desktop Workstation
set "DIR=%~dp0"
set "TARGET=%DIR%app\index.html"

echo Starting Fullstop Suite Desktop Workstation...

rem 1. Check PATH for msedge
where msedge >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" msedge --app="%TARGET%"
    exit /b 0
)

rem 2. Check standard Microsoft Edge installation locations
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET%"
    exit /b 0
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET%"
    exit /b 0
)
if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" --app="%TARGET%"
    exit /b 0
)

rem 3. Check PATH for chrome
where chrome >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" chrome --app="%TARGET%"
    exit /b 0
)

rem 4. Check standard Google Chrome installation locations
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%TARGET%"
    exit /b 0
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="%TARGET%"
    exit /b 0
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" --app="%TARGET%"
    exit /b 0
)

rem 5. Check Brave browser
if exist "%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe" (
    start "" "%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe" --app="%TARGET%"
    exit /b 0
)

rem 6. Fallback to default browser
start "" "%TARGET%"
exit /b 0
