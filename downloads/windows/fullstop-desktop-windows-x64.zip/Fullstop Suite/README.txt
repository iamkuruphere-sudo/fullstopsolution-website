======================================================================
FULLSTOP SUITE — WINDOWS 64-BIT (x64)
Official Website: https://www.fullstopsolution.in
Security Architecture: 100% Client-Side Memory, Zero Telemetry
======================================================================

QUICK START:
Double-click 'Launch Fullstop Suite.bat'.
The workstation will launch in standalone desktop window mode.

HOW TO VERIFY SIGNATURE INTEGRITY:
Open PowerShell in the download folder and run:
  Get-FileHash fullstop-desktop-windows-x64.zip -Algorithm SHA256

Compare the resulting hash with the published SHA256SUMS.txt.
