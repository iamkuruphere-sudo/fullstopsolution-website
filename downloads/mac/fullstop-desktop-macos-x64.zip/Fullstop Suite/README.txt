======================================================================
FULLSTOP SOLUTION DESKTOP SUITE - macOS INTEL (x64)
Official Website: https://www.fullstopsolution.in
Security Architecture: 100% Client-Side Memory, Zero Telemetry
======================================================================

QUICK START:
Double-click 'Fullstop Suite.command' or double-click 'app/index.html'
in any browser (Safari, Chrome, Brave, Arc, Edge, Firefox).

ARCHITECTURE VERIFICATION:
Target Architecture: macOS Darwin (x64)
Binary Type: Universal Sandboxed HTML5/WebCrypto Local Execution

HOW TO VERIFY SIGNATURE INTEGRITY:
Run the following terminal command inside this folder:
  shasum -a 256 "Fullstop Suite.command"
Or verify the parent zip against downloads/SHA256SUMS.txt:
  shasum -a 256 fullstop-desktop-macos-x64.zip

All utilities (Meta Tag Studio, Password Generator, JSON Formatter,
Invoice Studio, QR Generator, GST Calculator, Hash Verifier) run
completely in-browser with zero internet connection required.
