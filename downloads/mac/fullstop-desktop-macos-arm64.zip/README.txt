======================================================================
FULLSTOP SUITE — macOS (ARM64)
Official Website: https://www.fullstopsolution.in
Security Architecture: 100% Client-Side Memory, Zero Telemetry
Universal 2 Binary: Native execution on Apple Silicon (M1/M2/M3/M4) and Intel (x86_64)
======================================================================

QUICK START:
Option 1: Double-click '⚡ Install & Authorize Fullstop Suite.command'
Option 2: Drag 'Fullstop Suite.app' to your /Applications folder.

HOW TO VERIFY SIGNATURE INTEGRITY:
Run in Terminal:
  shasum -a 256 "Fullstop Suite.app/Contents/MacOS/FullstopSuite"
Compare with official ledger: https://www.fullstopsolution.in/downloads/SHA256SUMS.txt
