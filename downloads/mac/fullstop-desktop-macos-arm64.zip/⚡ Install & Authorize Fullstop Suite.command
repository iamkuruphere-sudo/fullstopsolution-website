#!/usr/bin/env bash
# Fullstop Suite — Automated macOS Installer & Gatekeeper Authorizer
set -euo pipefail
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

echo "================================================================="
echo " Installing Fullstop Suite to /Applications"
echo "================================================================="
rm -rf "/Applications/Fullstop Suite.app"
cp -R "$DIR/Fullstop Suite.app" "/Applications/"
xattr -cr "/Applications/Fullstop Suite.app" 2>/dev/null || true
codesign --force --deep --options runtime --sign - "/Applications/Fullstop Suite.app" 2>/dev/null || true

echo "✓ Fullstop Suite installed to /Applications with valid code signature."
echo "Launching Fullstop Suite..."
open -a "/Applications/Fullstop Suite.app"
