#!/bin/bash
# Fullstop Solution Desktop Launcher for macOS (Apple Silicon - arm64)
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
echo "Launching Fullstop Solution Desktop Suite (100% Client-Side Privacy)..."
open "$DIR/app/index.html"
